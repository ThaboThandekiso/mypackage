# mypackage
This package was created as an example of how to create your own Python package

# How to install
...